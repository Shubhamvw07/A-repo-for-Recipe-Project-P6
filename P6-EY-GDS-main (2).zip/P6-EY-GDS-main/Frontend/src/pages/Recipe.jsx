import React from 'react'

function Recipe() {
  return (
    <div>
      Recipe
    </div>
  )
}

export default Recipe
